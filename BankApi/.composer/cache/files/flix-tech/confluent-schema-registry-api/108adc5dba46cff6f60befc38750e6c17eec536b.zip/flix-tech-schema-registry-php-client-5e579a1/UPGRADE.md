# Upgrade guide

Here BC breaks between major versions and upgrade paths are described.

## 3.x to 4.x

- 3 new methods in `CacheAdapterInterface`. See [this commit message](https://github.com/flix-tech/schema-registry-php-client/commit/ebf27bd3fb793ac7501a99983ad99628d75f0b9e)
for explanation and upgrade path.

## 6.x to 7.x

- PHP 7.1 support was dropped and the library is making use of the full PHP 7.2 feature set
