---
title: Requirements
weight: 2
---

Laravel Kafka requires **PHP 8.0+** and **Laravel 8+**

This package also requires the `rdkafka` php extension, which you can install by following [this documentation](https://github.com/edenhill/librdkafka#installation)