---
title: Questions and issues
weight: 4
---

Find yourself stuck using the package? found a bug? Do you have general questions or suggestion to improve laravel kafka? Feel free to [create an issue in GitHub](https://github.com/mateusjunges/laravel-kafka/issues/new/choose) and i'll try to address it as soon as possible.

If you have found a bug regarding security, please email me at [mateus@junges.dev](mailto:mateus@junges.dev) instead of using the issue tracker.