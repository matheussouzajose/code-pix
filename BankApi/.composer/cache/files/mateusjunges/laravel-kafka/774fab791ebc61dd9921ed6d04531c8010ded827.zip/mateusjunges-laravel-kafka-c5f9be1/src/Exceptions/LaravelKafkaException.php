<?php

namespace Junges\Kafka\Exceptions;

use Exception;

abstract class LaravelKafkaException extends Exception
{
}
