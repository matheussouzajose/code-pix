<?php

namespace Junges\Kafka\Tests\Consumers;

use Junges\Kafka\Commit\Contracts\CommitterFactory;
use Junges\Kafka\Commit\VoidCommitter;
use Junges\Kafka\Config\Config;
use Junges\Kafka\Consumers\CallableConsumer;
use Junges\Kafka\Consumers\Consumer;
use Junges\Kafka\Contracts\CanConsumeMessages;
use Junges\Kafka\Contracts\KafkaConsumerMessage;
use Junges\Kafka\Exceptions\KafkaConsumerException;
use Junges\Kafka\Facades\Kafka;
use Junges\Kafka\Message\ConsumedMessage;
use Junges\Kafka\Message\Deserializers\JsonDeserializer;
use Junges\Kafka\Tests\Fakes\FakeConsumer;
use Junges\Kafka\Tests\Fakes\FakeHandler;
use Junges\Kafka\Tests\LaravelKafkaTestCase;
use RdKafka\Message;

class ConsumerTest extends LaravelKafkaTestCase
{
    private ?CanConsumeMessages $stoppableConsumer = null;
    private bool $stoppableConsumerStopped = false;
    private string $stoppedConsumerMessage = "";

    public function testItConsumesAMessageSuccessfullyAndCommit()
    {
        $fakeHandler = new FakeHandler();

        $message = new Message();
        $message->err = 0;
        $message->key = 'key';
        $message->topic_name = 'test-topic';
        $message->payload = '{"body": "message payload"}';
        $message->offset = 0;
        $message->partition = 1;
        $message->headers = [];

        $this->mockConsumerWithMessage($message);

        $this->mockProducer();

        $config = new Config(
            broker: 'broker',
            topics: ['test-topic'],
            securityProtocol: 'security',
            commit: 1,
            groupId: 'group',
            consumer: $fakeHandler,
            sasl: null,
            dlq: null,
            maxMessages: 1,
            maxCommitRetries: 1
        );

        $consumer = new Consumer($config, new JsonDeserializer());
        $consumer->consume();

        $this->assertInstanceOf(ConsumedMessage::class, $fakeHandler->lastMessage());
    }

    public function testItCanConsumeMessages()
    {
        $message = new Message();
        $message->err = 0;
        $message->key = 'key';
        $message->topic_name = 'test';
        $message->payload = '{"body": "message payload"}';
        $message->headers = [];
        $message->partition = 1;
        $message->offset = 0;

        $this->mockConsumerWithMessage($message);

        $this->mockProducer();

        $consumer = Kafka::createConsumer(['test'])
            ->withHandler($fakeConsumer = new FakeConsumer())
            ->withAutoCommit()
            ->withMaxMessages(1)
            ->build();

        $consumer->consume();

        $this->assertInstanceOf(ConsumedMessage::class, $fakeConsumer->getMessage());
    }

    public function testConsumeMessageWithError()
    {
        $this->mockProducer();

        $this->expectException(KafkaConsumerException::class);

        $fakeHandler = new FakeHandler();

        $config = new Config(
            broker: 'broker',
            topics: ['test-topic'],
            securityProtocol: 'security',
            commit: 1,
            groupId: 'group',
            consumer: $fakeHandler,
            sasl: null,
            dlq: null,
            maxMessages: 1,
            maxCommitRetries: 1
        );

        $message = new Message();
        $message->err = 1;
        $message->topic_name = 'test-topic';

        $this->mockConsumerWithMessageFailingCommit($message);

        $consumer = new Consumer($config, new JsonDeserializer());
        $consumer->consume();
    }

    public function testCanStopConsume()
    {
        $message = new Message();
        $message->err = 0;
        $message->key = 'key';
        $message->topic_name = 'test';
        $message->payload = '{"body": "message payload"}';
        $message->offset = 0;
        $message->partition = 1;
        $message->headers = [];

        $message2 = new Message();
        $message2->err = 0;
        $message2->key = 'key2';
        $message2->topic_name = 'test2';
        $message2->payload = '{"body": "message payload2"}';
        $message2->offset = 0;
        $message2->partition = 1;
        $message2->headers = [];

        $this->mockConsumerWithMessage($message, $message2);

        $this->mockProducer();

        $this->stoppableConsumer = Kafka::createConsumer(['test'])
            ->withHandler(function (KafkaConsumerMessage $message) {
                if ($this->stoppableConsumer && $message->getKey() === 'key2') {
                    $this->stoppableConsumer->onStopConsuming(function () {
                        $this->stoppedConsumerMessage = "Consumer stopped.";
                        $this->stoppableConsumerStopped = true;
                    })->stopConsuming();
                }
            })
            ->withAutoCommit()
            ->build();

        $this->stoppableConsumer->consume();

        $this->assertSame(2, $this->stoppableConsumer->consumedMessagesCount());
        $this->assertTrue($this->stoppableConsumerStopped);
        $this->assertSame("Consumer stopped.", $this->stoppedConsumerMessage);
    }

    public function testItAcceptsCustomCommitter(): void
    {
        $fakeHandler = new FakeHandler();

        $message = new Message();
        $message->err = 0;
        $message->key = 'key';
        $message->topic_name = 'test-topic';
        $message->payload = '{"body": "message payload"}';
        $message->offset = 0;
        $message->partition = 1;
        $message->headers = [];

        $this->mockConsumerWithMessage($message);

        $this->mockProducer();

        $config = new Config(
            broker: 'broker',
            topics: ['test-topic'],
            securityProtocol: 'security',
            commit: 1,
            groupId: 'group',
            consumer: $fakeHandler,
            sasl: null,
            dlq: null,
            maxMessages: 1,
            maxCommitRetries: 1
        );

        $mockedCommitterFactory = $this->createMock(CommitterFactory::class);
        $mockedCommitterFactory->expects($this->once())
            ->method('make')
            ->willReturn(new VoidCommitter());

        $consumer = new Consumer($config, new JsonDeserializer(), $mockedCommitterFactory);
        $consumer->consume();

        $this->assertInstanceOf(ConsumedMessage::class, $fakeHandler->lastMessage());

        $committer = $this->getPropertyWithReflection('committer', $consumer);
        $this->assertInstanceOf(VoidCommitter::class, $committer);
    }

    public function testItCanRestartConsumer()
    {
        $message = new Message();
        $message->err = 0;
        $message->key = 'key';
        $message->topic_name = 'test';
        $message->payload = '{"body": "message payload"}';
        $message->offset = 0;
        $message->partition = 1;
        $message->headers = [];

        $message2 = new Message();
        $message2->err = 0;
        $message2->key = 'key2';
        $message2->topic_name = 'test';
        $message2->payload = '{"body": "message payload2"}';
        $message2->offset = 0;
        $message2->partition = 1;
        $message2->headers = [];

        $this->mockConsumerWithMessage($message, $message2);
        $this->mockProducer();
        

        $fakeHandler = new CallableConsumer(
            function (KafkaConsumerMessage $message) {
                // sleep 100 miliseconds to simulate restart interval check
                usleep(100 * 1000);
                $this->artisan('kafka:restart-consumers');
            },
            []
        );

        $config = new Config(
            broker: 'broker',
            topics: ['test-topic'],
            securityProtocol: 'security',
            commit: 1,
            groupId: 'group',
            consumer: $fakeHandler,
            sasl: null,
            dlq: null,
            maxMessages: 2,
            maxCommitRetries: 1,
            restartInterval : 100
        );

        $consumer = new Consumer($config, new JsonDeserializer());
        $consumer->consume();

        //finaly only one message should be consumed
        $this->assertEquals(1, $consumer->consumedMessagesCount());
    }
}
