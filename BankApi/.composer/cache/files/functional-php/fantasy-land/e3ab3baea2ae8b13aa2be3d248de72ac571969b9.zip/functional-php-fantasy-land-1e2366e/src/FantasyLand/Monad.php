<?php

declare(strict_types=1);

namespace FunctionalPHP\FantasyLand;

interface Monad extends
    Applicative,
    Chain
{
}
