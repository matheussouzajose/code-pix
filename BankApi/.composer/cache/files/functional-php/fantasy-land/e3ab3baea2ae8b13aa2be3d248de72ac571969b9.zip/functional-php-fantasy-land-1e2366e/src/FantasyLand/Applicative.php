<?php

declare(strict_types=1);

namespace FunctionalPHP\FantasyLand;

interface Applicative extends
    Apply,
    Pointed
{
}
